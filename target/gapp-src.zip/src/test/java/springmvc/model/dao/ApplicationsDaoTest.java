package springmvc.model.dao;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.testng.AbstractTransactionalTestNGSpringContextTests;
import org.testng.annotations.Test;

@Test(groups = "ApplicationsDaoTest")
@ContextConfiguration(locations = "classpath:applicationContext.xml")
public class ApplicationsDaoTest   extends AbstractTransactionalTestNGSpringContextTests {

	  @Autowired
	   ApplicationDao applicationsDao;
	  
	 /* 
	  @Test
	   public void getApplications()
	   {
	       assert applicationsDao.getApplicationsPerDepartment("Accounting Department").size() == 1;
	   }
	  
	  @Test
	  public void getApplicationsForStudent()
	  {
		  assert applicationsDao.getApplicationsForStudent("student1@localhost.localdomain").size() == 1;
	  }*/
}
