drop table application_status_update;

drop table application_status;

drop table additional_field_values;

drop table academic_record;

drop table applications;

drop table additional_fields;

drop table programs;

drop table departments;

drop table users cascade;

drop table educational_background;

drop table student_information;

drop table user_role;

