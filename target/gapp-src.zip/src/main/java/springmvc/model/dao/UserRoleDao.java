package springmvc.model.dao;

import springmvc.model.UserRole;

public interface UserRoleDao {

	UserRole getRole( String rolename);
	
}
