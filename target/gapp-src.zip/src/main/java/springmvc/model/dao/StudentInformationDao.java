package springmvc.model.dao;
public interface StudentInformationDao {

	
	
	
}
